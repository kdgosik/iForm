# iForm
R package for the iForm procedure


## Installation

You can install this package using the devtools function install_github.

```
install.packages("devtools")
devtools::install_github("kdgosik/iForm")
```

You can also install using CRAN
```
install.packages("iForm")
```
